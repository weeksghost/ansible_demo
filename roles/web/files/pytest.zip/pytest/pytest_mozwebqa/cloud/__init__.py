from browserstack import BrowserStack
from saucelabs import SauceLabs

browserstack = BrowserStack
saucelabs = SauceLabs
