from pytest_mozwebqa import *

__version__ = pytest_mozwebqa.__version__
